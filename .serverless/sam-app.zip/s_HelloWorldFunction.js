
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'leozenberg',
  applicationName: 'sam-app',
  appUid: 'L0QPSLPGBTtydpYyfr',
  orgUid: '9zGqDyRTfmL5Tk5X3p',
  deploymentUid: '8f51e3e5-86bb-4bf6-9abc-d10e8b50a8c0',
  serviceName: 'sam-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'sam-app-dev-HelloWorldFunction', timeout: 10 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}